from django.urls import path
from login import views

urlpatterns = [

    path(r'login/', views.login_handle),

]
