from django.shortcuts import render
from django.http import JsonResponse
from utils.common import *

# Create your views here.

def login_handle(request):
    """
    登录处理
    :param request:
    :return:code(200,400), result(0,1), message
    """

    value = None
    result = {'value':value}

    return success_resp(result)