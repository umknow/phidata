from django.apps import AppConfig


class StatisIndexConfig(AppConfig):
    name = 'statis_index'
