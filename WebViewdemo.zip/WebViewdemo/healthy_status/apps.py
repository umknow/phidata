from django.apps import AppConfig


class HealthyStatusConfig(AppConfig):
    name = 'healthy_status'
