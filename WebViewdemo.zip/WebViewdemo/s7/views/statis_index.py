from django.http import JsonResponse
from django.views import View
from collections import defaultdict
import datetime
import random
import csv
import redis
from utils.tool_func import *

from utils.common import *


class TotalDwmRate(View):
    '''
    get the data from mysql about the s7 user living info,include
    dailyliving rate,weekliving rate,monthliving rate
    return: the living data in the format of json
        2.5.1 totaldwmRate:
        {
        “code”:200,
        “result”:data,
        “message”:’successful’
        } ,
            其中，data格式为：
                {
        “totalDevice”:value,
        “dliving_rate”:value,
        “dRatio”:value,
        “wliving_rate”:value,
        “wRatio”:value,
        “mliving_rate”:value,
        “mRation”:value,
        }
    '''
    def __init__(self):
        # self.result_dict = defaultdict(list)
        pass

    def get(self,request):
        # 先取出需要的哦数据

        self.result_dict = {'test_data':'wang'}

        return success_resp(self.result_dict)


class MacConstituteInfo(View):
    """
        设备构成数据的返回（这是查询的get请求）
        携带参数： date_id : 2017-12
    """
    def get(self, request):
        # dict = request.GET
        date = get(request, 'date_id')
        # date = dict.get('date_id', '')  # 后面会根据时间查询数据表中对应的数据
        data = {'date':date}
        return success_resp(data)


class MacLiveness(View):
    """
        设备活跃度，前端通过滑动查看，所以，返回全部对应数据在前端进行选择性展示
        侧边栏切换页面请求方式： get （调整前端可视化视图现在不用向后端发送请求）
        在本页面中会有三个按钮请求，（按日，周，月时间参数进行发送请求获取数据）
        页面内部请求方式：get
        参数类型： 尚未明确
    """
    def get(self, request):
        date = get(request, 'date_id')
        data = {}
        return success_resp(data)


class AddMacInfo(View):
    """
        新增设备信息页面
        请求方式：get
        页面内部按钮请求：携带参数
        参数类型： 尚未明确（按基本ri，周，月进行显示）
    """
    def get(self, request):
        date = get(request, 'date_id')
        data = {}
        return success_resp(data)


class RetainedMacInfo(View):
    """
        留存设备（库存）页面数据显示信息
        请求方式：get
        同上
    """
    def get(self, request):
        date = get(request, 'date_id')
        data = {}
        return success_resp(data)

