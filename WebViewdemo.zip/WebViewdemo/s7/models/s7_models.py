from django.db import models
from db.BaseModel import *  # 这是基类模板（自定义的）
from utils.tool_func import *


class OverallStatisIndexInfoManager(models.Manager):
    """
        总体统计指标数据表的管理器类
        需要获取设备总量：mac_quantity

    """
    pass


class OverallRegionalDistribManager(models.Manager):
    """
        用户总体区域分布表管理器类
    """
    pass


class OverallResultManager(models.Manager):
    """
        用户总体结果信息表管理器类
    """
    pass


class TgiDistributionManager(models.Manager):
    """
        户TGI分布信息表管理器类
    """
    pass


class HealthyStatusManager(models.Manager):
    """
        用户健康状况分布表管理器类
    """
    pass


class OverallStatisticalIndexInfo(models.Model):
    """
        存储总体统计指标数据，其中，用户设备总量实时更新，其余每日更新
    """
    update_time = models.CharField(max_length=20, default='NULL', db_index=True)
    mac_quantity = models.CharField(max_length=20, default='NULL')
    dailyMac = models.CharField(max_length=20, default='NULL')
    dailyAddMac = models.CharField(max_length=20, default='NULL')
    dailyRemainMac = models.CharField(max_length=20, default='NULL')
    dailyMac_Rate = models.CharField(max_length=20, default='NULL')
    dailyMac_Ratio = models.CharField(max_length=20, default='NULL')
    weekMac = models.CharField(max_length=20, default='NULL')
    weekAddMac = models.CharField(max_length=20, default='NULL')
    weekRemainMac = models.CharField(max_length=20, default='NULL')
    weekMac_Rate = models.CharField(max_length=20, default='NULL')
    weekMac_Ratio = models.CharField(max_length=20, default='NULL')
    monthMac = models.CharField(max_length=20, default='NULL')
    monthAddMac = models.CharField(max_length=20, default='NULL')
    monthRemainMac = models.CharField(max_length=20, default='NULL')
    monthMac_Rate = models.CharField(max_length=20, default='NULL')
    monthMac_Ratio = models.CharField(max_length=20, default='NULL')
    slientMac = models.CharField(max_length=20, default='NULL')
    slientMac_Rate = models.CharField(max_length=20, default='NULL')
    slientMac_Ratio = models.CharField(max_length=20, default='NULL')
    loseMac = models.CharField(max_length=20, default='NULL')
    loseMac_Rate = models.CharField(max_length=20, default='NULL')
    loseMac_Ratio = models.CharField(max_length=20, default='NULL')
    backMac = models.CharField(max_length=20, default='NULL')
    backMac_Rate = models.CharField(max_length=20, default='NULL')
    backMac_Ratio = models.CharField(max_length=20, default='NULL')
    loyalMac = models.CharField(max_length=20, default='NULL')
    loyalMac_Rate = models.CharField(max_length=20, default='NULL')
    loyalMac_Ratio = models.CharField(max_length=20, default='NULL')
    objects = OverallStatisIndexInfoManager()


class OverallRegionalDistribution(models.Model):
    """
        用户总体区域分布表，其中，50表示60前
    """
    update_time = models.CharField(max_length=20, default='NULL', db_index=True)
    male_00  = models.CharField(max_length=20, default='NULL')
    female_00  = models.CharField(max_length=20, default='NULL')
    male_90 = models.CharField(max_length=20, default='NULL')
    female_90 = models.CharField(max_length=20, default='NULL')
    male_80 = models.CharField(max_length=20, default='NULL')
    female_80 = models.CharField(max_length=20, default='NULL')
    male_70 = models.CharField(max_length=20, default='NULL')
    female_70 = models.CharField(max_length=20, default='NULL')
    male_60 = models.CharField(max_length=20, default='NULL')
    female_60 = models.CharField(max_length=20, default='NULL')
    male_50 = models.CharField(max_length=20, default='NULL')
    female_50 = models.CharField(max_length=20, default='NULL')
    prototaluser = models.CharField(max_length=20, default='NULL')
    ptotalmale = models.CharField(max_length=20, default='NULL')
    ptotalfemale = models.CharField(max_length=20, default='NULL')
    maleRegionTGI = models.CharField(max_length=20, default='NULL')
    femaleRegionTGI = models.CharField(max_length=20, default='NULL')
    RegionTGI_00 = models.CharField(max_length=20, default='NULL')
    RegionTGI_90 = models.CharField(max_length=20, default='NULL')
    RegionTGI_80 = models.CharField(max_length=20, default='NULL')
    RegionTGI_70 = models.CharField(max_length=20, default='NULL')
    RegionTGI_60 = models.CharField(max_length=20, default='NULL')
    RegionTGI_50 = models.CharField(max_length=20, default='NULL')
    province = models.CharField(max_length=20, default='NULL')
    objects = OverallRegionalDistribManager()


class OverallResult(models.Model):
    """
        用户总体结果，其中，50表示60前，男女比例存储格式为value_value，例如：44%_56%
    """
    update_time = models.CharField(max_length=20, default='NULL', db_index=True)
    totaluser  = models.CharField(max_length=20, default='NULL')
    totalmale  = models.CharField(max_length=20, default='NULL')
    totalfemale  = models.CharField(max_length=20, default='NULL')
    maleTofemale  = models.CharField(max_length=20, default='NULL')
    total_00male  = models.CharField(max_length=20, default='NULL')
    total_00female  = models.CharField(max_length=20, default='NULL')
    maleTofemale00  = models.CharField(max_length=20, default='NULL')
    total_90male  = models.CharField(max_length=20, default='NULL')
    total_90female  = models.CharField(max_length=20, default='NULL')
    maleTofemale90  = models.CharField(max_length=20, default='NULL')
    total_80male  = models.CharField(max_length=20, default='NULL')
    total_80female  = models.CharField(max_length=20, default='NULL')
    maleTofemale80  = models.CharField(max_length=20, default='NULL')
    total_70male  = models.CharField(max_length=20, default='NULL')
    total_70female  = models.CharField(max_length=20, default='NULL')
    maleTofemale70  = models.CharField(max_length=20, default='NULL')
    total_60male  = models.CharField(max_length=20, default='NULL')
    total_60female  = models.CharField(max_length=20, default='NULL')
    maletTofemale60  = models.CharField(max_length=20, default='NULL')
    total_50male  = models.CharField(max_length=20, default='NULL')
    total_50female  = models.CharField(max_length=20, default='NULL')
    maleTofemale50  = models.CharField(max_length=20, default='NULL')

    objects = OverallResultManager()


class TgiDistribution(models.Model):
    """
        用户TGI分布,其中50表示60后前,每月更新
    """
    update_time = models.CharField(max_length=20, default='NULL', db_index=True)
    totaluser  = models.CharField(max_length=20, default='NULL')
    BMI_0_Num  = models.CharField(max_length=20, default='NULL')
    BMI_0_Rate  = models.CharField(max_length=20, default='NULL')
    BMI_1_Num  = models.CharField(max_length=20, default='NULL')
    BMI_1_Rate  = models.CharField(max_length=20, default='NULL')
    BMI_2_Num  = models.CharField(max_length=20, default='NULL')
    BMI_2_Rate  = models.CharField(max_length=20, default='NULL')
    BMI_3_Num  = models.CharField(max_length=20, default='NULL')
    BMI_3_Rate  = models.CharField(max_length=20, default='NULL')
    Bfat_0_Num  = models.CharField(max_length=20, default='NULL')
    Bfat_0_Rate  = models.CharField(max_length=20, default='NULL')
    Bfat_1_Num  = models.CharField(max_length=20, default='NULL')
    Bfat_1_Rate  = models.CharField(max_length=20, default='NULL')
    Bfat_2_Num  = models.CharField(max_length=20, default='NULL')
    Bfat_2_Rate  = models.CharField(max_length=20, default='NULL')
    Bfat_3_Num  = models.CharField(max_length=20, default='NULL')
    Bfat_3_Rate  = models.CharField(max_length=20, default='NULL')
    Hfat_0_Num  = models.CharField(max_length=20, default='NULL')
    Hfat_0_Rate  = models.CharField(max_length=20, default='NULL')
    Hfat_1_Num  = models.CharField(max_length=20, default='NULL')
    Hfat_1_Rate  = models.CharField(max_length=20, default='NULL')
    Hfat_2_Num  = models.CharField(max_length=20, default='NULL')
    Hfat_2_Rate  = models.CharField(max_length=20, default='NULL')
    Hfat_3_Num  = models.CharField(max_length=20, default='NULL')
    Hfat_3_Rate  = models.CharField(max_length=20, default='NULL')
    Water_0_Num  = models.CharField(max_length=20, default='NULL')
    Water_0_Rate  = models.CharField(max_length=20, default='NULL')
    Water_1_Num  = models.CharField(max_length=20, default='NULL')
    Water_1_Rate  = models.CharField(max_length=20, default='NULL')
    Muscle_0_Num  = models.CharField(max_length=20, default='NULL')
    Muscle_0_Rate  = models.CharField(max_length=20, default='NULL')
    Muscle_1_Num  = models.CharField(max_length=20, default='NULL')
    Muscle_1_Rate  = models.CharField(max_length=20, default='NULL')
    Muscle_2_Num  = models.CharField(max_length=20, default='NULL')
    Muscle_2_Rate  = models.CharField(max_length=20, default='NULL')
    Cadre_0_Num  = models.CharField(max_length=20, default='NULL')
    Cadre_0_Rate  = models.CharField(max_length=20, default='NULL')
    Cadre_1_Num  = models.CharField(max_length=20, default='NULL')
    Cadre_1_Rate  = models.CharField(max_length=20, default='NULL')
    Bmet_0_Num  = models.CharField(max_length=20, default='NULL')
    Bmet_0_Rate  = models.CharField(max_length=20, default='NULL')
    Bmet_1_Num  = models.CharField(max_length=20, default='NULL')
    Bmet_1_Rate  = models.CharField(max_length=20, default='NULL')
    Protein_0_Num  = models.CharField(max_length=20, default='NULL')
    Protein_0_Rate  = models.CharField(max_length=20, default='NULL')
    Protein_1_Num  = models.CharField(max_length=20, default='NULL')
    Protein_1_Rate  = models.CharField(max_length=20, default='NULL')
    Protein_2_Num  = models.CharField(max_length=20, default='NULL')
    Protein_2_Rate  = models.CharField(max_length=20, default='NULL')

    objects = TgiDistributionManager()


class HealthyStatus(models.Model):
    """
        用户健康状况，信息表
    """
    update_time = models.CharField(max_length=20, default='NULL', db_index=True)
    MuchThin  = models.CharField(max_length=20, default='NULL')
    LittleThin  = models.CharField(max_length=20, default='NULL')
    MuscleSlim  = models.CharField(max_length=20, default='NULL')
    Slim  = models.CharField(max_length=20, default='NULL')
    Healthy  = models.CharField(max_length=20, default='NULL')
    Muscle  = models.CharField(max_length=20, default='NULL')
    Sporter  = models.CharField(max_length=20, default='NULL')
    Littlefat  = models.CharField(max_length=20, default='NULL')
    Fat  = models.CharField(max_length=20, default='NULL')
    MuchFat  = models.CharField(max_length=20, default='NULL')

    objects = HealthyStatusManager()
