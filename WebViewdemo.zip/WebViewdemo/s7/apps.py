from django.apps import AppConfig


class S7Config(AppConfig):
    name = 's7'
