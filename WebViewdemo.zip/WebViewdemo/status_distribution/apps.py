from django.apps import AppConfig


class StatusDistributionConfig(AppConfig):
    name = 'status_distribution'
