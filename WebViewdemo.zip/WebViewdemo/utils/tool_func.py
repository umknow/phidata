from django.db import models
from django.contrib import messages
import hashlib
from django.shortcuts import redirect
# from django.core.urlresolvers import reverse


"""
这个模块是用来封装，django基本功能函数
"""

# get
def get(request, key):
    return request.GET.get(key, '').strip()  # strip()的功能是取出字符串首尾两段的所有空格

# post
def post(request, key):
    return request.POST.get(key, '').strip()

def post_list(request, key):
    return request.POST.getlist(key)

# 获取COOKIE
def get_cookie(request, key):
    return request.COOKIES.get(key, '')

# 设置COOKIE
def set_cookie(response, key, value):
    response.set_cookie(key, value, max_age=60*60*12)  # 设置了有效时间为一天

# 删除COOKIE
def del_cookie(response, key):
    response.delete_cookie(key)

# 获取session
def get_session(request, key):
    return request.session.get(key, '')

# 设置session
def set_session(request, key, value):
    request.session[key] = value

# 设置session 过期时间
def set_session_expriry(request, extime):
    request.session.set_expiry(extime)

# 删除session
def del_session(request):
    request.session.flush()
