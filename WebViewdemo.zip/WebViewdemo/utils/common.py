from django.http import JsonResponse
from utils.code_status import *


def success_resp(result):
    """
        封装请求成功响应体
    :return:
                {
        “code”:200,
        “result”:data,
        “message”:’successful’
        }
    """
    response_dict = {
        "code":200,
        "result":result,
        "message": error_map
    }
    return JsonResponse(response_dict)


def faild_resp(result):
    """
        封装请求失败响应体
    :return:
        {
        “code”:400,
        “result”:data,
        “message”:’successful’
        }
    """
    response_dict = {
        "code": 400,
        "result": result,
        "message": 'faild'
    }
    return JsonResponse(response_dict)