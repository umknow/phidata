from django.urls import path
from phidata.views import (views as views_api,\
                            statis_index as index_api,\
                            status_distribution as status_api,\
                            healthy_status as healthy_api,
                           )

#from web front
#1./phidata/livingdata/
#2./phidata/querydata/2018-01-02
#3./phidata/locationdata/
#4./phidata/

urlpatterns = [
    # path('livingdata/', views_api.S7UserLivingRateView.as_view()), # 旧

    # 1.总体统计指标模块
    path('totaldwmRate/$',index_api.TotalDwmRate.as_view()),    # 需要该页面所有数据，即包括设备构成数据
    # path('deviceComp/(.+)/$',index_api ),    # 通过时间请求设备构成数据: 127.0.0.1/phidata/s7/deviceComp/2017-12
    # path('livingDevice/$',index_api ),    # 设备活跃度页面（包括：日，月，周） 后面可能携带参数：2017-12-12
    # path('addDevice/$',index_api ),     # 新增设备页面（包括：日，月，周） 后面可能携带参数：2017-12-12
    # path('remainDevice/$',index_api ),    # 预留设备页面（包括：日，月，周） 后面可能携带参数：2017-12-12
    #
    # # 2.用户成分分布模块
    # path('totalUserDistri/$', status_api),  # 返回性别分布数据，年龄分布数据及地域分布数据
    # path('querydata/sexDistri/$', status_api),  # 查询指定日期的性别分布数据
    # path('querydata/ageDistri/$', status_api),  # 查询指定日期的年龄分布数据
    # path('Querydata/regionDistri/$', status_api),  # 查询指定日期的地域分布数据
    #
    # path('userTGIDistri/$', status_api),  # 返回地域年龄、性别年龄、性别地域TGI数据
    # path('querydata/ageRegionTGI/$', status_api),  # 返回指定日期的地域年龄TGI
    # path('querydata/sexAgeTGI/$', status_api),  # 返回指定日期的性别年龄TGI
    # path('querydata/sexRegionTGI/$', status_api),  # 返回指定日期的性别地域TGI
    #
    # # 3.用户健康状况模块
    # path('userHealth/$', healthy_api),  # 返回10项体型标签数据以及健康指标分布
    # path('deviceComp/$', healthy_api),  # 返回指定日期的10项体型标签数据
    # path('deviceComp/$', healthy_api),  # 返回指定日期的健康指标数据

]