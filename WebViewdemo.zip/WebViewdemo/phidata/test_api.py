from django.core.cache import cache
# 按单个视图缓存
from django.views.decorators.cache import cache_page

# 设置参数缓存
cache.set('wang', 'yongsheng', 60*2)

cache.get('wang')