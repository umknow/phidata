from django.apps import AppConfig


class PhidataConfig(AppConfig):
    name = 'phidata'
