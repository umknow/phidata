
# -*- coding:utf-8 -*-
from django.core.management.base import BaseCommand
# 设置缓存
from django.core.cache import cache

# setting.py 中
# # 使用redis数据库缓存
# CACHES = {
#     "default": {
#     "BACKEND": "django_redis.cache.RedisCache",
#     "LOCATION": "redis://127.0.01:6379/1",  # 后面的1的意思是存储在redis  1号库
#     "OPTIONS":{
#         'CLIENT_CLASS': "django_redis.client.DefaultClient",
#         "CONNECTION_POOL_KWARGS": {"max_connections": 100},   # 支持高并发的（最大连接数）
#     },
#     "KEY_PREFIX": "example"
#     },# 必须配置default
#     # 'apps': {
#     # 'BACKEND': 'django.core.cache.backends.db.DatabaseCache',
#     # 'LOCATION': 'sheng',
#     # }
# }
# # 添加缓存的有效时间
# CACHE_TTL = 60*60


class Command(BaseCommand):
    '''
   测试使用
    '''
    def handle(self, *args, **options):
        print('ssss')