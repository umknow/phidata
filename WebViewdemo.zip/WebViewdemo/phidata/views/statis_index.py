from django.http import JsonResponse
from django.views import View
from collections import defaultdict
import datetime
import random
import csv
import redis

from utils.common import *

class TotalDwmRate(View):
    '''
    get the data from mysql about the s7 user living info,include
    dailyliving rate,weekliving rate,monthliving rate
    return: the living data in the format of json
        2.5.1 totaldwmRate:
        {
        “code”:200,
        “result”:data,
        “message”:’successful’
        } ,
            其中，data格式为：
                {
        “totalDevice”:value,
        “dliving_rate”:value,
        “dRatio”:value,
        “wliving_rate”:value,
        “wRatio”:value,
        “mliving_rate”:value,
        “mRation”:value,
        }

    '''
    def __init__(self):
        self.result_dict = defaultdict(list)

    def get(self,request):
        # 先取出需要的哦数据

        self.result_dict = None

        return success_resp(self.result_dict)
