# '''
# @description:handle mysql and redis,according to the request from web front
# @return:response to web front the data in format of json
# @author:wenxuyi
# 2017.12.29
# '''
#
# from django.http import JsonResponse
# # from phidata.models import dailyliving,weekliving,monthliving
# from django.views import View
# from collections import defaultdict
# import datetime
# import random
# import csv
# import redis
#
#
#
# def getBeforeDate(n):
#     '''
#     get the before n days date
#     :param n:stand for n days
#     :return: str:xxxx-xx-xx
#     '''
#     today = datetime.date.today()
#     oneday = datetime.timedelta(days=n)
#     return today - oneday
#
# def gettotalMac():
#     '''
#     read csv file from local dir
#     :return:str:date,totalmac
#     '''
#     update_date = ""
#     totalmac = ""
#     with open('/home/DjangoProj/WebViewdemo/localdata/s7totalmac.csv', 'rb', newline='') as csvfie:
#         csvmac = csv.reader(csvfie)
#         for row in csvmac:
#             if len(row):
#                 update_date = row[0]
#                 totalmac = row[1]
#             else:
#                 break
#     return totalmac
#
#
# class QueryTable():
#
#     def __init__(self,querydate,tablename):
#         '''
#         get data from mysql
#         :param querydate: the query date
#         :param tablename: the query table
#         '''
#         self.querydate = querydate
#         self.tablename = tablename
#         self.livingrate = ""
#         self.tableContentDict = defaultdict(str)
#         self.totalmac = gettotalMac()
#
#         if self.tablename == 'daily':
#             self.TableObj = dailyliving.objects.get( update_date = self.querydate )
#             self.livingrate = "dailyliving_rate"
#         elif self.tablename == 'week':
#             self.TableObj = weekliving.objects.get( update_date = self.querydate )
#             self.livingrate = "weekliving_rate"
#         elif self.tablename == 'month':
#             self.TableObj = monthliving.objects.get( update_date = self.querydate )
#             self.livingrate = "monthliving_rate"
#         else:
#             print("query error")
#
#     def getTableContent(self):
#         '''
#         :return:
#         '''
#         self.tableContentDict['mac_quantity'] = self.TableObj.mac_quantity
#         livingrate = int(self.tableContentDict['mac_quantity']) / self.totalmac
#         self.tableContentDict[self.livingrate] = "{:.1%}".format(livingrate)
#         self.tableContentDict['growth_rate'] = self.TableObj.growth_rate
#         return self.tableContentDict
#
#     def query(self):
#         '''
#         :return:
#         '''
#         self.getTableContent()
#
#
# class QueryRedis():
#     '''
#     According to the input para,return the data about the date,including:
#     dailyliving,weekliving,monthliving,location and so on;
#     '''
#     def __init__(self,querydate):
#         '''
#         :param querydate:
#         '''
#         self.redisHandler = redis.StrictRedis(host='localhost', port=6379, db=0, encoding='utf-8', decode_responses=True)
#         self.querydate = querydate
#         self.result = defaultdict(dict)
#
#     def getdata(self):
#         '''
#         get data from redis
#         :return:
#         '''
#         if self.redisHandler.hexists(self.querydate, "daily"):
#
#             self.result['dailyliving'] = format('daily', self.redisHandler.hmget(self.querydate, "daily"))
#             self.result['weekliving'] = format('daily', self.redisHandler.hmget(self.querydate, "weekly"))
#             self.result['monthliving'] = format('daily', self.redisHandler.hmget(self.querydate, "monthly"))
#             self.result['totalmac'] = {'totalmac' : gettotalMac()}
#         else:
#             self.result['dailyliving'] = QueryTable(self.querydate, 'daily').query()
#             self.result['weekliving'] = QueryTable(self.querydate, 'week').query()
#             self.result['monthliving'] = QueryTable(self.querydate, 'month').query()
#             self.result['totalmac'] = {'totalmac': gettotalMac()}
#             self.updateRedis()
#
#         return self.result
#
#     def formatRedisData(self, requestType, dataStr):
#         '''
#         :param requestType:
#         :param dataStr:
#         :return:
#         '''
#         self.formatdataDict = defaultdict(str)
#         if dataStr is not None:
#             dataList = dataStr.split()
#             if requestType == 'daily':
#                 self.formatdataDict['mac_quantity'] = dataList[0]
#                 self.formatdataDict['dailyliving_rate'] = dataList[1]
#                 self.formatdataDict['growth_rate'] = dataList[2]
#             elif requestType == 'weekly':
#                 self.formatdataDict['mac_quantity'] = dataList[0]
#                 self.formatdataDict['weekliving_rate'] = dataList[1]
#                 self.formatdataDict['growth_rate'] = dataList[2]
#             elif requestType == 'monthly':
#                 self.formatdataDict['mac_quantity'] = dataList[0]
#                 self.formatdataDict['monthliving_rate'] = dataList[1]
#                 self.formatdataDict['growth_rate'] = dataList[2]
#
#     def updateRedis(self):
#         '''
#         update the data saved in the Redis
#         :return:
#         '''
#         setValue = defaultdict(str)
#         setValue['daily'] = '%s%s%s%s%s'.format(self.result['dailyliving']['mac_quantity'], ' ',
#                                         self.result['dailyliving']['dailyliving_rate'],' ',
#                                         self.result['dailyliving']['growth_rate'])
#         setValue['weekly'] = '%s%s%s%s%s'.format(self.result['weekliving']['mac_quantity'], ' ',
#                                         self.result['weekliving']['weekliving_rate'],' ',
#                                         self.result['weekliving']['growth_rate'])
#         setValue['monthly'] = '%s%s%s%s%s'.format(self.result['monthliving']['mac_quantity'], ' ',
#                                         self.result['monthliving']['monthliving_rate'],' ',
#                                         self.result['monthliving']['growth_rate'])
#         self.redisHandler.hmset(self.querydate, setValue)
#
#
# # handle the route to URL
# class S7UserLivingRateView( View ):
#     '''
#     get the data from mysql about the s7 user living info,include
#     dailyliving rate,weekliving rate,monthliving rate
#     return: the living data in the format of json
#     '''
#     def __init__(self):
#         self.responseDict = defaultdict(dict)
#
#     def get(self,request):
#         if request.method == "GET":
#             querydate = getBeforeDate(1)  # 获取前n天的日期
#             self.responseDict['result'] = QueryRedis.getdata(querydate)  # 通过日期获取对应数据（缓存中的）
#
#         return JsonResponse({'code':200, 'update':querydate, 'result':self.responseDict['result'], 'message':'successful'})
#
