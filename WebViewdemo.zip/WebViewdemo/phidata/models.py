'''
@description:create table
@return:no
@author:wenxuyi
2017.12.28
'''
from django.db import models

# Create your models here.

# the total quantity of router mac
class totalmac(models.Model):
    id = models.IntegerField(primary_key=id,auto_created=True)
    update_date = models.CharField(max_length=20)
    total_mac = models.CharField(max_length=20)

# the dailyliving table
class dailyliving(models.Model):
    id = models.IntegerField(primary_key=id,auto_created=True)
    update_date = models.CharField(max_length=20)
    mac_quantity = models.CharField(max_length=20)
    dailyliving_rate = models.CharField(max_length=10,default='NULL')
    growth_rate = models.CharField(max_length=10,default='NULL')

# the weekliving table
class weekliving(models.Model):
    id = models.IntegerField(primary_key=id,auto_created=True)
    update_date = models.CharField(max_length=20)
    mac_quantity = models.CharField(max_length=20)
    weekliving_rate = models.CharField(max_length=10,default='NULL')
    growth_rate = models.CharField(max_length=10,default='NULL')

# the monthliving table
class monthliving(models.Model):
    id = models.IntegerField(primary_key=id,auto_created=True)
    update_date = models.CharField(max_length=20)
    mac_quantity = models.CharField(max_length=20)
    monthliving_rate = models.CharField(max_length=10,default='NULL')
    growth_rate = models.CharField(max_length=10,default='NULL')

# the slient user table
class slientuser(models.Model):
    id = models.IntegerField(primary_key=id,auto_created=True)
    update_date = models.CharField(max_length=20)
    mac_quantity = models.CharField(max_length=20)
    slientuser_rate = models.CharField(max_length=10)
    growth_rate = models.CharField(max_length=10)

# the lost user table
class lostuser(models.Model):
    id = models.IntegerField(primary_key=id,auto_created=True)
    update_date = models.CharField(max_length=20)
    mac_quantity = models.CharField(max_length=20)
    lostuser_rate = models.CharField(max_length=10)
    growth_rate = models.CharField(max_length=10)

# the back user table
class backuser(models.Model):
    id = models.IntegerField(primary_key=id,auto_created=True)
    update_date = models.CharField(max_length=20)
    mac_quantity = models.CharField(max_length=20)
    backuser_rate = models.CharField(max_length=10)
    growth_rate = models.CharField(max_length=10)

# the loyalty user table
class loyaltyuser(models.Model):
    id = models.IntegerField(primary_key=id,auto_created=True)
    update_date = models.CharField(max_length=20)
    mac_quantity = models.CharField(max_length=20)
    loyaltyuser_rate = models.CharField(max_length=10)
    growth_rate = models.CharField(max_length=10)
